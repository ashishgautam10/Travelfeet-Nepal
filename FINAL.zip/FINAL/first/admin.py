from django.contrib import admin
from first.models import Form,Feedback,GalleryImage,Information_slide

# Register your models here.

admin.site.register(Form)
admin.site.register(Feedback)
admin.site.register(GalleryImage)
admin.site.register(Information_slide)