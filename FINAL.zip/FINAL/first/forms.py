from django import forms


# class forminput(forms.ModelForm):
#     class Meta():
#         model = Form
#         fields = '__all__'





# class FormName(forms.Form):
#     Name = forms.CharField()
#     Email = forms.EmailField()
#     Comment = form.CharField(widget=forms.Textarea)
    # botcatcher =forms.CharField(required=False, widget=forms.HiddenInput)
